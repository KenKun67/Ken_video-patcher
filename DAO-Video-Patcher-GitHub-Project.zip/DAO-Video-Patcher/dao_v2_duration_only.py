#!/usr/bin/env python3
"""Experimental MP4 metadata patcher: set only mvhd.duration to unknown.

No media streams are re-encoded or remuxed. The source file is never modified.
Requires Python 3 and ffprobe (install with: pkg install python ffmpeg).
Usage: python dao_v2_duration_only.py input.mp4 output.mp4

Supports ordinary, non-fragmented MP4 files with one video track and standard
stco/co64 offsets. It refuses structures it cannot safely validate. This is
an experiment, not a guarantee of any platform's upload behaviour.
"""
import json, os, re, shutil, struct, subprocess, sys, tempfile
from pathlib import Path

CONTAINERS = {b'moov', b'trak', b'mdia', b'minf', b'stbl', b'edts', b'dinf', b'udta', b'tref'}
TC_RE = re.compile(r'^\d{2}:\d{2}:\d{2}:\d{2}$')

class Box:
    def __init__(self, typ, raw=None, children=None, start=0, header=8):
        self.typ, self.raw, self.children, self.start, self.header = typ, raw, children, start, header
    @property
    def size(self): return len(self.to_bytes())
    def to_bytes(self):
        if self.children is None:
            return self.raw
        payload = b''.join(c.to_bytes() for c in self.children)
        size = 8 + len(payload)
        if size > 0xffffffff: raise ValueError(f'{self.typ!r} too large for 32-bit box')
        return struct.pack('>I4s', size, self.typ) + payload

def parse_boxes(data, base=0):
    boxes=[]; p=0
    while p < len(data):
        if p+8 > len(data): raise ValueError(f'Trailing bytes while parsing atom at {base+p}')
        size, typ = struct.unpack_from('>I4s', data, p); header=8
        if size == 1:
            if p+16 > len(data): raise ValueError('Truncated extended-size atom')
            size=struct.unpack_from('>Q',data,p+8)[0]; header=16
        elif size == 0: size=len(data)-p
        if size < header or p+size > len(data):
            raise ValueError(f'Invalid atom {typ!r} size={size} at offset {base+p}')
        raw=data[p:p+size]
        if typ in CONTAINERS:
            children=parse_boxes(raw[header:], base+p+header)
            box=Box(typ, children=children, start=base+p, header=header)
        else:
            box=Box(typ, raw=raw, start=base+p, header=header)
        boxes.append(box); p+=size
    return boxes

def box(typ, payload):
    if len(payload)+8 > 0xffffffff: raise ValueError('Atom too large')
    return struct.pack('>I4s', len(payload)+8, typ) + payload

def child(boxobj, typ):
    if boxobj.children is None: return None
    return next((c for c in boxobj.children if c.typ == typ), None)

def fullbox_version(raw): return raw[8]
def read_u32(raw, off): return struct.unpack_from('>I', raw, off)[0]
def write_u32(raw, off, value):
    x=bytearray(raw); struct.pack_into('>I',x,off,value); return bytes(x)

def get_track_id(trak):
    tkhd=child(trak,b'tkhd')
    if not tkhd: raise ValueError('Track missing tkhd')
    raw=tkhd.raw; v=raw[8]
    return read_u32(raw, 20 if v==0 else 28)

def get_track_duration(trak):
    tkhd=child(trak,b'tkhd'); raw=tkhd.raw; v=raw[8]
    return read_u32(raw, 28) if v==0 else struct.unpack_from('>Q',raw,36)[0]

def mdhd_fields(trak):
    mdia=child(trak,b'mdia'); mdhd=child(mdia,b'mdhd') if mdia else None
    if not mdhd: raise ValueError('Track missing mdhd')
    raw=mdhd.raw; v=raw[8]
    if v==0: return read_u32(raw,20), read_u32(raw,24)
    return read_u32(raw,28), struct.unpack_from('>Q',raw,32)[0]

def handler_type(trak):
    mdia=child(trak,b'mdia'); hdlr=child(mdia,b'hdlr') if mdia else None
    return hdlr.raw[16:20] if hdlr and len(hdlr.raw)>=20 else b''

def track_ids(moov):
    return [get_track_id(b) for b in moov.children if b.typ==b'trak']

def upgrade_mvhd(mvhd, next_track_id):
    raw=mvhd.raw
    if raw[8] == 1:
        updated=bytearray(raw)
        updated[32:40]=b'\xff'*8  # unknown movie duration, as in the reference
        struct.pack_into('>I',updated,len(updated)-4,next_track_id)
        return Box(b'mvhd', raw=bytes(updated), start=mvhd.start)
    if raw[8] != 0: raise ValueError('Unsupported mvhd version')
    body=raw[8:]
    # Version 1 widens creation/modification times and duration to 64 bits.
    vf=bytes([1])+body[1:4]
    creation=struct.pack('>Q', read_u32(raw,12))
    modification=struct.pack('>Q', read_u32(raw,16))
    timescale=raw[20:24]
    duration=b'\xff'*8  # matches the reference style: unknown movie duration
    remainder=bytearray(raw[28:]) # rate, volume, matrix, predefined, next_track_ID
    struct.pack_into('>I', remainder, len(remainder)-4, next_track_id)
    payload=vf+creation+modification+timescale+duration+bytes(remainder)
    return Box(b'mvhd', raw=box(b'mvhd',payload), start=mvhd.start)

def append_tref(trak, tmcd_id):
    children=list(trak.children or [])
    # QuickTime reference layout places the video track in alternate group 1.
    tkhd=next((c for c in children if c.typ==b'tkhd'),None)
    if tkhd is not None and tkhd.raw[8]==0:
        updated=bytearray(tkhd.raw)
        struct.pack_into('>H',updated,42,1)  # alternate_group field
        tkhd=Box(b'tkhd',raw=bytes(updated),start=tkhd.start)
        children=[tkhd if c.typ==b'tkhd' else c for c in children]
    tref=next((c for c in children if c.typ==b'tref'),None)
    tmcd_ref=box(b'tmcd',struct.pack('>I',tmcd_id))
    if tref:
        # Avoid adding duplicate tmcd references.
        if any(c.typ==b'tmcd' for c in (tref.children or [])): raise ValueError('Video track already has a tmcd reference')
        tref.children.append(Box(b'tmcd',raw=tmcd_ref))
    else:
        ref=Box(b'tref',children=[Box(b'tmcd',raw=tmcd_ref)])
        # Match the reference layout: tref follows the media information.
        children.append(ref)
    return Box(b'trak',children=children,start=trak.start)

def make_tmcd_track(track_id, movie_duration, video_timescale, video_duration, fps_num, fps_den, frame_duration, sample_offset, use_co64=False):
    # QuickTime timecode track in the same atom layout as the supplied reference.
    # tkhd: version 0, flags 3, track ID, duration in movie timescale, identity matrix.
    tkhd_payload = (b'\x00\x00\x00\x03' + b'\x00'*8 + struct.pack('>II',track_id,0) + struct.pack('>I',0)
                    + b'\x00'*8 + struct.pack('>hh',0,0) + b'\x00\x00' + b'\x00\x00'
                    + struct.pack('>9I',0x00010000,0,0,0,0x00010000,0,0,0,0x40000000)
                    + struct.pack('>II',0,0))
    tkhd=box(b'tkhd',tkhd_payload)
    # mdhd uses video media timescale/duration, und language.
    mdhd=box(b'mdhd', b'\x00'*4+b'\x00'*8+struct.pack('>II',video_timescale,0)+b'\x55\xc4\x00\x00')
    hdlr=box(b'hdlr',b'\x00'*4+b'\x00'*4+b'tmcd'+b'\x00'*12+b'\x00')
    # Generic media header as in reference (gmhd/gmin/text).
    gmhd=box(b'gmhd',box(b'gmin',b'\x00'*16)+box(b'text',b''))
    dinf=box(b'dinf',box(b'dref',b'\x00'*4+struct.pack('>I',1)+box(b'url ',b'\x00\x00\x00\x01')))
    # QuickTime tmcd sample description, one sample of four-byte frame count.
    entry_payload=b'\x00'*6+struct.pack('>H',1)+b'\x00'*8+struct.pack('>II',video_timescale,frame_duration)+bytes([min(255,round(fps_num/fps_den)),0])
    entry=box(b'tmcd',entry_payload)
    stsd=box(b'stsd',b'\x00'*4+struct.pack('>I',1)+entry)
    stts=box(b'stts',b'\x00'*4+struct.pack('>I',1)+struct.pack('>II',1,frame_duration))
    stsc=box(b'stsc',b'\x00'*4+struct.pack('>I',1)+struct.pack('>III',1,1,1))
    stsz=box(b'stsz',b'\x00'*4+struct.pack('>II',4,1)+struct.pack('>I',4))
    if use_co64:
        chunk_offsets=box(b'co64',b'\x00'*4+struct.pack('>IQ',1,sample_offset))
    else:
        chunk_offsets=box(b'stco',b'\x00'*4+struct.pack('>II',1,sample_offset))
    stbl=box(b'stbl',stsd+stts+stsc+stsz+chunk_offsets)
    minf=box(b'minf',gmhd+dinf+stbl)
    mdia=box(b'mdia',mdhd+hdlr+minf)
    return box(b'trak',tkhd+mdia)

def patch_offsets_in_box(boxobj, threshold, delta):
    """Adjust stco/co64 offsets that point after the old moov."""
    if boxobj.children is not None:
        for c in boxobj.children: patch_offsets_in_box(c,threshold,delta)
    elif boxobj.typ in (b'stco',b'co64'):
        raw=bytearray(boxobj.raw); count=read_u32(raw,12); width=4 if boxobj.typ==b'stco' else 8
        if 16+count*width > len(raw): raise ValueError(f'Malformed {boxobj.typ.decode()} box')
        for i in range(count):
            off=16+i*width
            val=read_u32(raw,off) if width==4 else struct.unpack_from('>Q',raw,off)[0]
            if val>=threshold:
                val+=delta
                if width==4:
                    if val>0xffffffff: raise ValueError('stco offset overflow; file needs co64 conversion')
                    struct.pack_into('>I',raw,off,val)
                else: struct.pack_into('>Q',raw,off,val)
        boxobj.raw=bytes(raw)

def ffprobe(path, packets=False):
    cmd=['ffprobe','-v','error','-show_streams','-show_format']
    if packets:
        cmd += ['-show_packets','-show_data_hash','sha256','-show_entries',
                'stream=index,codec_type,codec_name,codec_tag_string,width,height,r_frame_rate,avg_frame_rate,sample_rate,channels,channel_layout:stream_tags=timecode:format=duration,size:packet=stream_index,pts,dts,duration,size,data_hash']
    cmd += ['-of','json',str(path)]
    p=subprocess.run(cmd,text=True,capture_output=True,timeout=3600)
    if p.returncode: raise RuntimeError((p.stderr or 'ffprobe failed')[-5000:])
    return json.loads(p.stdout)

def parse_ratio(s):
    a,b=s.split('/')
    return int(a),int(b)

def top_level_atoms(path):
    """Read only top-level atom headers, not large mdat payloads."""
    file_size=path.stat().st_size
    atoms=[]
    pos=0
    with path.open('rb') as f:
        while pos < file_size:
            f.seek(pos)
            head=f.read(16)
            if len(head)<8: raise ValueError(f'Truncated top-level atom at {pos}')
            size,typ=struct.unpack_from('>I4s',head,0); header=8
            if size==1:
                if len(head)<16: raise ValueError(f'Truncated extended atom at {pos}')
                size=struct.unpack_from('>Q',head,8)[0]; header=16
            elif size==0:
                raise ValueError('Input contains a size-zero top-level atom; rewrite it with FFmpeg first.')
            if size<header or pos+size>file_size:
                raise ValueError(f'Invalid top-level atom {typ!r} at offset {pos}')
            atoms.append((typ,pos,size,header))
            pos+=size
    return file_size,atoms

def read_movie(path):
    file_size,top=top_level_atoms(path)
    moov_records=[a for a in top if a[0]==b'moov']
    if len(moov_records)!=1: raise ValueError('Expected exactly one moov atom')
    moov_typ,moov_start,moov_size,moov_header=moov_records[0]
    if any(a[0] in (b'moof',b'mvex',b'sidx',b'ssix',b'mfra') for a in top):
        raise ValueError('Fragmented/indexed MP4 is not supported by this direct patcher')
    with path.open('rb') as f:
        f.seek(moov_start); moov_raw=f.read(moov_size)
    moov=parse_boxes(moov_raw,base=moov_start)[0]
    if any(c.typ==b'mvex' for c in moov.children):
        raise ValueError('Fragmented MP4 is not supported by this direct patcher')
    if any(b.typ in (b'saio',b'iloc') for b in walk(moov)):
        raise ValueError('MP4 contains auxiliary/item offsets this patcher does not rewrite')
    tracks=[b for b in moov.children if b.typ==b'trak']
    if any(handler_type(t)==b'tmcd' for t in tracks): raise ValueError('Input already contains a timecode track')
    videos=[t for t in tracks if handler_type(t)==b'vide']
    if len(videos)!=1: raise ValueError(f'Expected one video track, found {len(videos)}')
    mvhd=child(moov,b'mvhd')
    if not mvhd: raise ValueError('moov has no mvhd')
    movie_timescale=read_u32(mvhd.raw,20 if mvhd.raw[8]==0 else 28)
    video=videos[0]
    video_timescale,video_duration=mdhd_fields(video)
    movie_duration=get_track_duration(video)
    if movie_duration in (0,0xffffffff,0xffffffffffffffff):
        movie_duration=round(video_duration*movie_timescale/video_timescale)
    return file_size,top,moov,mvhd,tracks,video,movie_timescale,movie_duration,video_timescale,video_duration

def walk(b):
    yield b
    for c in b.children or []: yield from walk(c)

def set_unknown_movie_duration(mvhd):
    """Set only mvhd.duration to all-ones (unknown), preserving every other field."""
    raw=bytearray(mvhd.raw)
    version=raw[8]
    if version==0:
        offset=24
        width=4
    elif version==1:
        offset=32
        width=8
    else:
        raise ValueError(f'Unsupported mvhd version: {version}')
    if len(raw)<offset+width:
        raise ValueError('Malformed mvhd atom: duration field is missing')
    raw[offset:offset+width]=b'\xff'*width
    return Box(b'mvhd',raw=bytes(raw),start=mvhd.start)

def main():
    if shutil.which('ffprobe') is None:
        print('ffprobe is required. Install with: pkg install ffmpeg')
        return 2
    if len(sys.argv)>=2:
        src_path=Path(sys.argv[1]).expanduser().resolve()
    else:
        src_path=Path(input('Input MP4 path: ').strip().strip('"').strip("'")).expanduser().resolve()
    if not src_path.is_file():
        print(f'Input file not found: {src_path}')
        return 1
    if len(sys.argv)>=3:
        dst=Path(sys.argv[2]).expanduser().resolve()
    else:
        default=src_path.with_name(src_path.stem+'_dao_v2.mp4')
        answer=input(f'Output path [{default}]: ').strip().strip('"').strip("'")
        dst=Path(answer).expanduser().resolve() if answer else default
    if src_path==dst:
        print('Output path must differ from input.')
        return 1
    if not dst.parent.is_dir():
        print(f'Output directory not found: {dst.parent}')
        return 1
    if dst.exists() and input(f'{dst} exists. Replace after verification? (y/N): ').strip().lower()!='y':
        print('Cancelled.')
        return 1
    temp=None
    try:
        # Structural preflight: rejects fragmented MP4, unsupported offsets and ambiguous tracks.
        (file_size,top,moov,mvhd,tracks,video,movie_scale,movie_dur,
         video_scale,video_dur)=read_movie(src_path)
        src_meta=ffprobe(src_path)
        vstreams=[s for s in src_meta.get('streams',[]) if s.get('codec_type')=='video']
        if len(vstreams)!=1:
            raise ValueError('Expected exactly one readable video stream')
        vs=vstreams[0]
        fps=vs.get('avg_frame_rate') or vs.get('r_frame_rate') or 'unknown'
        print('Preflight passed:')
        print(f'  Video: {vs.get("codec_name")} {vs.get("width")}x{vs.get("height")}')
        print(f'  Frame rate metadata: avg={vs.get("avg_frame_rate", "?")}, nominal={vs.get("r_frame_rate", "?")}')
        print(f'  Container size: {file_size:,} bytes')
        print('  Profile: mvhd-duration-only (no tmcd track; no media re-encode)')

        # Replace exactly one fixed-width field. Atom size and chunk offsets remain unchanged.
        newchildren=[set_unknown_movie_duration(c) if c is mvhd else c for c in moov.children]
        newmoov=Box(b'moov',children=newchildren,start=moov.start)
        moov_bytes=newmoov.to_bytes()
        if len(moov_bytes)!=len(moov.to_bytes()):
            raise ValueError('Internal error: duration-only patch unexpectedly changed moov size')

        fd,temp_name=tempfile.mkstemp(prefix='.'+dst.name+'.',suffix=dst.suffix or '.mp4',dir=str(dst.parent))
        os.close(fd)
        temp=Path(temp_name)
        with src_path.open('rb') as fin, temp.open('wb') as fout:
            replaced=False
            for typ,atom_start,atom_size,atom_header in top:
                if typ==b'moov' and atom_start==moov.start:
                    if replaced: raise ValueError('Unexpected duplicate moov atom')
                    fout.write(moov_bytes); replaced=True
                else:
                    fin.seek(atom_start)
                    remaining=atom_size
                    while remaining:
                        chunk=fin.read(min(remaining,1024*1024))
                        if not chunk: raise ValueError('Unexpected EOF while copying source atom')
                        fout.write(chunk); remaining-=len(chunk)
            if not replaced: raise ValueError('Could not locate moov atom while writing output')

        # Verify both parseability and exact preservation of audio/video packet payloads + timing.
        out_meta=ffprobe(temp)
        src_packets=ffprobe(src_path,True)
        out_packets=ffprobe(temp,True)
        def av_streams(data):
            return [s for s in data.get('streams',[]) if s.get('codec_type') in ('video','audio')]
        def stream_packets(data,index):
            return [p for p in data.get('packets',[]) if p.get('stream_index')==index]
        source_streams=av_streams(src_meta)
        output_streams=av_streams(out_meta)
        if len(source_streams)!=len(output_streams):
            raise ValueError('Verification failed: audio/video stream count changed')
        remaining=list(output_streams)
        for original in source_streams:
            match=next((s for s in remaining if s.get('codec_type')==original.get('codec_type')
                        and s.get('codec_name')==original.get('codec_name')),None)
            if match is None:
                raise ValueError('Verification failed: source audio/video stream is missing')
            remaining.remove(match)
            a=stream_packets(src_packets,original['index'])
            b=stream_packets(out_packets,match['index'])
            for field in ('data_hash','pts','dts','duration','size'):
                if [p.get(field) for p in a] != [p.get(field) for p in b]:
                    raise ValueError(f'Verification failed: {original["codec_type"]} packet {field} changed')
        if temp.stat().st_size!=src_path.stat().st_size:
            raise ValueError('Verification failed: file size changed in a fixed-width metadata patch')

        temp.replace(dst); temp=None
        print('\nPASS: duration-only patch verified.')
        print('  Audio/video packet hashes and timestamps match the source.')
        print('  No video/audio re-encoding was performed.')
        print('  Only mvhd.duration was changed to the MP4 unknown-duration value.')
        print(f'  Output: {dst}')
        print('\nImportant: this does not guarantee TikTok will preserve the upload. Test against an untreated copy.')
        return 0
    except Exception as exc:
        print(f'\nERROR: {exc}')
        return 1
    finally:
        if temp is not None:
            try: temp.unlink(missing_ok=True)
            except OSError: pass

if __name__=='__main__':
    sys.exit(main())
