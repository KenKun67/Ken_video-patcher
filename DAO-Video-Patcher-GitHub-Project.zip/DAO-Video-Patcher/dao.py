#!/usr/bin/env python3
"""Direct MP4 QuickTime timecode-track patcher (no media remux/re-encode).

Termux setup: pkg install python ffmpeg
Usage: python dao.py input.mp4 output.mp4

This edits MP4 atoms directly. It supports ordinary, non-fragmented MP4 files
with one video track and standard stco/co64 chunk offsets. It refuses formats
whose offset structures it cannot safely update. The source is never modified.
"""
import json, os, re, shutil, struct, subprocess, sys, tempfile
from pathlib import Path

CONTAINERS = {b'moov', b'trak', b'mdia', b'minf', b'stbl', b'edts', b'dinf', b'udta', b'tref'}
TC_RE = re.compile(r'^\d{2}:\d{2}:\d{2}:\d{2}$')

class Box:
    def __init__(self, typ, raw=None, children=None, start=0, header=8):
        self.typ, self.raw, self.children, self.start, self.header = typ, raw, children, start, header
    @property
    def size(self): return len(self.to_bytes())
    def to_bytes(self):
        if self.children is None:
            return self.raw
        payload = b''.join(c.to_bytes() for c in self.children)
        size = 8 + len(payload)
        if size > 0xffffffff: raise ValueError(f'{self.typ!r} too large for 32-bit box')
        return struct.pack('>I4s', size, self.typ) + payload

def parse_boxes(data, base=0):
    boxes=[]; p=0
    while p < len(data):
        if p+8 > len(data): raise ValueError(f'Trailing bytes while parsing atom at {base+p}')
        size, typ = struct.unpack_from('>I4s', data, p); header=8
        if size == 1:
            if p+16 > len(data): raise ValueError('Truncated extended-size atom')
            size=struct.unpack_from('>Q',data,p+8)[0]; header=16
        elif size == 0: size=len(data)-p
        if size < header or p+size > len(data):
            raise ValueError(f'Invalid atom {typ!r} size={size} at offset {base+p}')
        raw=data[p:p+size]
        if typ in CONTAINERS:
            children=parse_boxes(raw[header:], base+p+header)
            box=Box(typ, children=children, start=base+p, header=header)
        else:
            box=Box(typ, raw=raw, start=base+p, header=header)
        boxes.append(box); p+=size
    return boxes

def box(typ, payload):
    if len(payload)+8 > 0xffffffff: raise ValueError('Atom too large')
    return struct.pack('>I4s', len(payload)+8, typ) + payload

def child(boxobj, typ):
    if boxobj.children is None: return None
    return next((c for c in boxobj.children if c.typ == typ), None)

def fullbox_version(raw): return raw[8]
def read_u32(raw, off): return struct.unpack_from('>I', raw, off)[0]
def write_u32(raw, off, value):
    x=bytearray(raw); struct.pack_into('>I',x,off,value); return bytes(x)

def get_track_id(trak):
    tkhd=child(trak,b'tkhd')
    if not tkhd: raise ValueError('Track missing tkhd')
    raw=tkhd.raw; v=raw[8]
    return read_u32(raw, 20 if v==0 else 28)

def get_track_duration(trak):
    tkhd=child(trak,b'tkhd'); raw=tkhd.raw; v=raw[8]
    return read_u32(raw, 28) if v==0 else struct.unpack_from('>Q',raw,36)[0]

def mdhd_fields(trak):
    mdia=child(trak,b'mdia'); mdhd=child(mdia,b'mdhd') if mdia else None
    if not mdhd: raise ValueError('Track missing mdhd')
    raw=mdhd.raw; v=raw[8]
    if v==0: return read_u32(raw,20), read_u32(raw,24)
    return read_u32(raw,28), struct.unpack_from('>Q',raw,32)[0]

def handler_type(trak):
    mdia=child(trak,b'mdia'); hdlr=child(mdia,b'hdlr') if mdia else None
    return hdlr.raw[16:20] if hdlr and len(hdlr.raw)>=20 else b''

def track_ids(moov):
    return [get_track_id(b) for b in moov.children if b.typ==b'trak']

def upgrade_mvhd(mvhd, next_track_id):
    raw=mvhd.raw
    if raw[8] == 1:
        updated=bytearray(raw)
        updated[32:40]=b'\xff'*8  # unknown movie duration, as in the reference
        struct.pack_into('>I',updated,len(updated)-4,next_track_id)
        return Box(b'mvhd', raw=bytes(updated), start=mvhd.start)
    if raw[8] != 0: raise ValueError('Unsupported mvhd version')
    body=raw[8:]
    # Version 1 widens creation/modification times and duration to 64 bits.
    vf=bytes([1])+body[1:4]
    creation=struct.pack('>Q', read_u32(raw,12))
    modification=struct.pack('>Q', read_u32(raw,16))
    timescale=raw[20:24]
    duration=b'\xff'*8  # matches the reference style: unknown movie duration
    remainder=bytearray(raw[28:]) # rate, volume, matrix, predefined, next_track_ID
    struct.pack_into('>I', remainder, len(remainder)-4, next_track_id)
    payload=vf+creation+modification+timescale+duration+bytes(remainder)
    return Box(b'mvhd', raw=box(b'mvhd',payload), start=mvhd.start)

def append_tref(trak, tmcd_id):
    children=list(trak.children or [])
    # QuickTime reference layout places the video track in alternate group 1.
    tkhd=next((c for c in children if c.typ==b'tkhd'),None)
    if tkhd is not None and tkhd.raw[8]==0:
        updated=bytearray(tkhd.raw)
        struct.pack_into('>H',updated,42,1)  # alternate_group field
        tkhd=Box(b'tkhd',raw=bytes(updated),start=tkhd.start)
        children=[tkhd if c.typ==b'tkhd' else c for c in children]
    tref=next((c for c in children if c.typ==b'tref'),None)
    tmcd_ref=box(b'tmcd',struct.pack('>I',tmcd_id))
    if tref:
        # Avoid adding duplicate tmcd references.
        if any(c.typ==b'tmcd' for c in (tref.children or [])): raise ValueError('Video track already has a tmcd reference')
        tref.children.append(Box(b'tmcd',raw=tmcd_ref))
    else:
        ref=Box(b'tref',children=[Box(b'tmcd',raw=tmcd_ref)])
        # Match the reference layout: tref follows the media information.
        children.append(ref)
    return Box(b'trak',children=children,start=trak.start)

def make_tmcd_track(track_id, movie_duration, video_timescale, video_duration, fps_num, fps_den, frame_duration, sample_offset, use_co64=False):
    # QuickTime timecode track in the same atom layout as the supplied reference.
    # tkhd: version 0, flags 3, track ID, duration in movie timescale, identity matrix.
    tkhd_payload = (b'\x00\x00\x00\x03' + b'\x00'*8 + struct.pack('>II',track_id,0) + struct.pack('>I',0)
                    + b'\x00'*8 + struct.pack('>hh',0,0) + b'\x00\x00' + b'\x00\x00'
                    + struct.pack('>9I',0x00010000,0,0,0,0x00010000,0,0,0,0x40000000)
                    + struct.pack('>II',0,0))
    tkhd=box(b'tkhd',tkhd_payload)
    # mdhd uses video media timescale/duration, und language.
    mdhd=box(b'mdhd', b'\x00'*4+b'\x00'*8+struct.pack('>II',video_timescale,0)+b'\x55\xc4\x00\x00')
    hdlr=box(b'hdlr',b'\x00'*4+b'\x00'*4+b'tmcd'+b'\x00'*12+b'\x00')
    # Generic media header as in reference (gmhd/gmin/text).
    gmhd=box(b'gmhd',box(b'gmin',b'\x00'*16)+box(b'text',b''))
    dinf=box(b'dinf',box(b'dref',b'\x00'*4+struct.pack('>I',1)+box(b'url ',b'\x00\x00\x00\x01')))
    # QuickTime tmcd sample description, one sample of four-byte frame count.
    entry_payload=b'\x00'*6+struct.pack('>H',1)+b'\x00'*8+struct.pack('>II',video_timescale,frame_duration)+bytes([min(255,round(fps_num/fps_den)),0])
    entry=box(b'tmcd',entry_payload)
    stsd=box(b'stsd',b'\x00'*4+struct.pack('>I',1)+entry)
    stts=box(b'stts',b'\x00'*4+struct.pack('>I',1)+struct.pack('>II',1,frame_duration))
    stsc=box(b'stsc',b'\x00'*4+struct.pack('>I',1)+struct.pack('>III',1,1,1))
    stsz=box(b'stsz',b'\x00'*4+struct.pack('>II',4,1)+struct.pack('>I',4))
    if use_co64:
        chunk_offsets=box(b'co64',b'\x00'*4+struct.pack('>IQ',1,sample_offset))
    else:
        chunk_offsets=box(b'stco',b'\x00'*4+struct.pack('>II',1,sample_offset))
    stbl=box(b'stbl',stsd+stts+stsc+stsz+chunk_offsets)
    minf=box(b'minf',gmhd+dinf+stbl)
    mdia=box(b'mdia',mdhd+hdlr+minf)
    return box(b'trak',tkhd+mdia)

def patch_offsets_in_box(boxobj, threshold, delta):
    """Adjust stco/co64 offsets that point after the old moov."""
    if boxobj.children is not None:
        for c in boxobj.children: patch_offsets_in_box(c,threshold,delta)
    elif boxobj.typ in (b'stco',b'co64'):
        raw=bytearray(boxobj.raw); count=read_u32(raw,12); width=4 if boxobj.typ==b'stco' else 8
        if 16+count*width > len(raw): raise ValueError(f'Malformed {boxobj.typ.decode()} box')
        for i in range(count):
            off=16+i*width
            val=read_u32(raw,off) if width==4 else struct.unpack_from('>Q',raw,off)[0]
            if val>=threshold:
                val+=delta
                if width==4:
                    if val>0xffffffff: raise ValueError('stco offset overflow; file needs co64 conversion')
                    struct.pack_into('>I',raw,off,val)
                else: struct.pack_into('>Q',raw,off,val)
        boxobj.raw=bytes(raw)

def ffprobe(path, packets=False):
    cmd=['ffprobe','-v','error','-show_streams','-show_format']
    if packets:
        cmd += ['-show_packets','-show_data_hash','sha256','-show_entries',
                'stream=index,codec_type,codec_name,codec_tag_string,width,height,r_frame_rate,avg_frame_rate,sample_rate,channels,channel_layout:stream_tags=timecode:format=duration,size:packet=stream_index,pts,dts,duration,size,data_hash']
    cmd += ['-of','json',str(path)]
    p=subprocess.run(cmd,text=True,capture_output=True,timeout=3600)
    if p.returncode: raise RuntimeError((p.stderr or 'ffprobe failed')[-5000:])
    return json.loads(p.stdout)

def parse_ratio(s):
    a,b=s.split('/')
    return int(a),int(b)

def top_level_atoms(path):
    """Read only top-level atom headers, not large mdat payloads."""
    file_size=path.stat().st_size
    atoms=[]
    pos=0
    with path.open('rb') as f:
        while pos < file_size:
            f.seek(pos)
            head=f.read(16)
            if len(head)<8: raise ValueError(f'Truncated top-level atom at {pos}')
            size,typ=struct.unpack_from('>I4s',head,0); header=8
            if size==1:
                if len(head)<16: raise ValueError(f'Truncated extended atom at {pos}')
                size=struct.unpack_from('>Q',head,8)[0]; header=16
            elif size==0:
                raise ValueError('Input contains a size-zero top-level atom; rewrite it with FFmpeg first.')
            if size<header or pos+size>file_size:
                raise ValueError(f'Invalid top-level atom {typ!r} at offset {pos}')
            atoms.append((typ,pos,size,header))
            pos+=size
    return file_size,atoms

def read_movie(path):
    file_size,top=top_level_atoms(path)
    moov_records=[a for a in top if a[0]==b'moov']
    if len(moov_records)!=1: raise ValueError('Expected exactly one moov atom')
    moov_typ,moov_start,moov_size,moov_header=moov_records[0]
    if any(a[0] in (b'moof',b'mvex',b'sidx',b'ssix',b'mfra') for a in top):
        raise ValueError('Fragmented/indexed MP4 is not supported by this direct patcher')
    with path.open('rb') as f:
        f.seek(moov_start); moov_raw=f.read(moov_size)
    moov=parse_boxes(moov_raw,base=moov_start)[0]
    if any(c.typ==b'mvex' for c in moov.children):
        raise ValueError('Fragmented MP4 is not supported by this direct patcher')
    if any(b.typ in (b'saio',b'iloc') for b in walk(moov)):
        raise ValueError('MP4 contains auxiliary/item offsets this patcher does not rewrite')
    tracks=[b for b in moov.children if b.typ==b'trak']
    if any(handler_type(t)==b'tmcd' for t in tracks): raise ValueError('Input already contains a timecode track')
    videos=[t for t in tracks if handler_type(t)==b'vide']
    if len(videos)!=1: raise ValueError(f'Expected one video track, found {len(videos)}')
    mvhd=child(moov,b'mvhd')
    if not mvhd: raise ValueError('moov has no mvhd')
    movie_timescale=read_u32(mvhd.raw,20 if mvhd.raw[8]==0 else 28)
    video=videos[0]
    video_timescale,video_duration=mdhd_fields(video)
    movie_duration=get_track_duration(video)
    if movie_duration in (0,0xffffffff,0xffffffffffffffff):
        movie_duration=round(video_duration*movie_timescale/video_timescale)
    return file_size,top,moov,mvhd,tracks,video,movie_timescale,movie_duration,video_timescale,video_duration

def walk(b):
    yield b
    for c in b.children or []: yield from walk(c)

def make_free():
    # Same 66-byte padding atom size as the reference output, but without its app-specific marker.
    return box(b'free',b'\x00'*58)

def main():
    if shutil.which('ffprobe') is None:
        print('ffprobe is required. Install with: pkg install ffmpeg'); return 2
    if len(sys.argv)>=2: src=Path(sys.argv[1]).expanduser().resolve()
    else:
        raw=input('Input MP4 path: ').strip().strip('"').strip("'")
        src=Path(raw).expanduser().resolve()
    if not src.is_file(): print(f'Input file not found: {src}'); return 1
    if len(sys.argv)>=3: dst=Path(sys.argv[2]).expanduser().resolve()
    else:
        raw=input(f'Output path [{src.with_name(src.stem+"_timecode.mp4")}]: ').strip().strip('"').strip("'")
        dst=Path(raw).expanduser().resolve() if raw else src.with_name(src.stem+'_timecode.mp4')
    if src==dst: print('Output path must differ from input.'); return 1
    if not dst.parent.is_dir(): print(f'Output directory not found: {dst.parent}'); return 1
    if dst.exists() and input(f'{dst} exists. Replace after verification? (y/N): ').strip().lower()!='y':
        print('Cancelled.'); return 1
    tc=input('Starting timecode [00:00:00:00]: ').strip() or '00:00:00:00'
    if not TC_RE.fullmatch(tc): print('Use HH:MM:SS:FF format.'); return 1
    hh,mm,ss,ff=map(int,tc.split(':'))
    if mm>59 or ss>59 or hh>99: print('Invalid timecode.'); return 1
    temp=None
    try:
        (file_size,top,moov,mvhd,tracks,video,movie_scale,movie_dur,video_scale,video_dur)=read_movie(src)
        # FPS metadata comes from ffprobe, not packet average (which may be VFR).
        meta=ffprobe(src)
        vs=next(s for s in meta['streams'] if s['codec_type']=='video')
        fps_num,fps_den=parse_ratio(vs.get('r_frame_rate','0/0'))
        if fps_num<=0 or fps_den<=0: raise ValueError('Could not determine video frame rate')
        nominal_fps=round(fps_num/fps_den)
        if nominal_fps<1 or nominal_fps>255: raise ValueError('Unsupported nominal frame rate for tmcd')
        if ff>=nominal_fps: raise ValueError(f'Frame field must be below {nominal_fps} for this video')
        frame_duration=round(video_scale*fps_den/fps_num)
        if frame_duration<1: raise ValueError('Could not determine timecode frame duration')
        frame_count=((hh*3600+mm*60+ss)*nominal_fps+ff)&0xffffffff
        ids=[get_track_id(t) for t in tracks]
        tc_id=max(ids,default=0)+1
        # Build a provisional timecode track; stco will be patched after moov size is known.
        use_co64 = file_size + 600 > 0xffffffff
        newtrack=Box(b'trak',raw=make_tmcd_track(tc_id,movie_dur,video_scale,video_dur,fps_num,fps_den,frame_duration,0,use_co64=use_co64))
        newtrack=parse_boxes(newtrack.raw)[0]
        new_video=append_tref(video,tc_id)
        newchildren=[]
        for c in moov.children:
            if c is mvhd: newchildren.append(upgrade_mvhd(c,tc_id+1))
            elif c is video: newchildren.append(new_video)
            else: newchildren.append(c)
        newchildren.append(newtrack)
        newmoov=Box(b'moov',children=newchildren,start=moov.start)
        preliminary=newmoov.to_bytes()
        delta=len(preliminary)-len(moov.to_bytes())
        old_moov_end=moov.start+len(moov.to_bytes())
        # If moov precedes media chunks, the expanded moov shifts those chunks.
        patch_offsets_in_box(newmoov,old_moov_end,delta)
        # Timecode sample is appended after all original top-level atoms.
        sample_offset=file_size+delta+8
        # Update new track's stco absolute offset.
        newtrack=next(c for c in newmoov.children if c.typ==b'trak' and get_track_id(c)==tc_id)
        chunk_offsets=next(c for c in walk(newtrack) if c.typ in (b'stco',b'co64'))
        if chunk_offsets.typ==b'stco':
            if sample_offset>0xffffffff: raise ValueError('New sample offset exceeds stco range; input needs co64 conversion')
            chunk_offsets.raw=write_u32(chunk_offsets.raw,16,sample_offset)
        else:
            updated=bytearray(chunk_offsets.raw); struct.pack_into('>Q',updated,16,sample_offset); chunk_offsets.raw=bytes(updated)
        # Rebuild final moov; ensure delta remains stable.
        moov_bytes=newmoov.to_bytes()
        if len(moov_bytes)-len(moov.to_bytes())!=delta: raise ValueError('Internal atom-size accounting error')
        fd,temp_name=tempfile.mkstemp(prefix='.'+dst.name+'.',suffix=dst.suffix or '.mp4',dir=str(dst.parent))
        os.close(fd)
        temp=Path(temp_name)
        with src.open('rb') as fin, temp.open('wb') as fout:
            for typ,atom_start,atom_size,atom_header in top:
                if typ==b'moov' and atom_start==moov.start:
                    fout.write(moov_bytes)
                else:
                    fin.seek(atom_start)
                    left=atom_size
                    while left:
                        chunk=fin.read(min(left,1024*1024))
                        if not chunk: raise ValueError('Unexpected EOF while copying input atom')
                        fout.write(chunk); left-=len(chunk)
            fout.write(box(b'mdat',struct.pack('>I',frame_count)))
            fout.write(make_free())
        # Check parsed output and compare source/output packet payload hashes + timestamps.
        outmeta=ffprobe(temp); srcpack=ffprobe(src,True); outpack=ffprobe(temp,True)
        outtracks=outmeta['streams']
        tmcd=[s for s in outtracks if s.get('codec_tag_string')=='tmcd']
        if not tmcd: raise ValueError('Verification failed: ffprobe cannot see a tmcd stream')
        if not any((s.get('tags') or {}).get('timecode')==tc for s in tmcd):
            raise ValueError('Verification failed: requested timecode is not readable from the tmcd track')
        if not any((s.get('tags') or {}).get('timecode')==tc for s in outtracks if s.get('codec_type')=='video'):
            raise ValueError('Verification failed: video stream does not expose the requested timecode')
        def avs(d): return [s for s in d['streams'] if s['codec_type'] in ('video','audio')]
        def packets(d,idx): return [p for p in d.get('packets',[]) if p['stream_index']==idx]
        dst_av=avs(outmeta); src_meta=meta
        remain=list(dst_av); ok=True
        for s in avs(src_meta):
            target=next((t for t in remain if t['codec_type']==s['codec_type'] and t.get('codec_name')==s.get('codec_name')),None)
            if target is None: raise ValueError('Verification failed: missing source audio/video stream')
            remain.remove(target)
            a,b=packets(srcpack,s['index']),packets(outpack,target['index'])
            for field in ('data_hash','pts','dts','duration','size'):
                if [p.get(field) for p in a] != [p.get(field) for p in b]:
                    ok=False; print(f'FAIL: {s["codec_type"]} packet {field} differs')
        if not ok: raise ValueError('Audio/video packet verification failed')
        if len(dst_av)!=len(avs(src_meta)): raise ValueError('Unexpected extra audio/video streams')
        temp.replace(dst); temp=None
        print('\nPASS: direct atom patch completed; media packets preserved.')
        print(f'Input size:  {src.stat().st_size:,} bytes')
        print(f'Output size: {dst.stat().st_size:,} bytes')
        print(f'Size change: {dst.stat().st_size-src.stat().st_size:+,} bytes')
        print(f'Timecode: {tc}; track ID: {tc_id}')
        print(f'Saved: {dst}')
        return 0
    except Exception as e:
        print(f'\nERROR: {e}')
        return 1
    finally:
        if temp is not None:
            try: temp.unlink(missing_ok=True)
            except OSError: pass

if __name__=='__main__': sys.exit(main())
