import os
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from starlette.background import BackgroundTask
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "500"))
MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024
ALLOWED_METHODS = {"timecode", "duration"}
app = FastAPI(title="DAO Video Patcher")

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/api/patch")
async def patch_video(
    video: UploadFile = File(...),
    method: str = Form("timecode"),
    timecode: str = Form("00:00:00:00"),
):
    if method not in ALLOWED_METHODS:
        raise HTTPException(400, "Unknown patching method.")
    filename = Path(video.filename or "video.mp4").name
    if Path(filename).suffix.lower() != ".mp4":
        raise HTTPException(415, "Please upload an MP4 file.")
    if method == "timecode":
        import re
        if not re.fullmatch(r"\d{2}:\d{2}:\d{2}:\d{2}", timecode):
            raise HTTPException(400, "Timecode must use HH:MM:SS:FF.")
        hh, mm, ss, ff = map(int, timecode.split(":"))
        if hh > 99 or mm > 59 or ss > 59:
            raise HTTPException(400, "Invalid timecode.")

    work = Path(tempfile.mkdtemp(prefix="dao-"))
    src = work / "input.mp4"
    dst = work / "patched.mp4"
    try:
        size = 0
        with src.open("wb") as out:
            while True:
                chunk = await video.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD_BYTES:
                    raise HTTPException(413, f"File exceeds the {MAX_UPLOAD_MB} MB upload limit.")
                out.write(chunk)
        if size < 16:
            raise HTTPException(400, "The uploaded file is empty or invalid.")

        script = BASE / ("dao.py" if method == "timecode" else "dao_v2_duration_only.py")
        command = ["python", str(script), str(src), str(dst)]
        try:
            result = subprocess.run(
                command,
                input=(timecode + "\n") if method == "timecode" else None,
                text=True,
                capture_output=True,
                timeout=900,
                cwd=BASE,
            )
        except subprocess.TimeoutExpired:
            raise HTTPException(408, "Patching timed out. Try a smaller video.")

        if result.returncode != 0 or not dst.exists():
            detail = (result.stderr or result.stdout or "Patching failed.")[-2500:]
            raise HTTPException(422, detail)

        # Return the processed file; the temporary directory is removed after response.
        output_name = f"{Path(filename).stem}_DAO.mp4"
        return FileResponse(
            dst,
            media_type="video/mp4",
            filename=output_name,
            background=BackgroundTask(shutil.rmtree, work, ignore_errors=True),
            headers={"X-DAO-Method": method, "X-DAO-Input-Bytes": str(size)},
        )
    finally:
        await video.close()
        # FileResponse streams after endpoint return, so cleanup is handled by its background task
        # in the normal success path below; on errors remove immediately.
        # (Success cleanup is registered by the response wrapper.)
        if not ("dst" in locals() and dst.exists() and 'result' in locals() and result.returncode == 0):
            shutil.rmtree(work, ignore_errors=True)

from starlette.background import BackgroundTask
_original_patch_video = patch_video

@app.post("/api/patch-file")
async def patch_file(
    video: UploadFile = File(...),
    method: str = Form("timecode"),
    timecode: str = Form("00:00:00:00"),
):
    # Compatibility alias; the main endpoint already returns a downloadable file.
    return await _original_patch_video(video, method, timecode)

app.mount("/", StaticFiles(directory=BASE / "static", html=True), name="static")
