const form = document.querySelector("#patchForm");
const fileInput = document.querySelector("#video");
const dropZone = document.querySelector("#dropZone");
const method = document.querySelector("#method");
const timecodeField = document.querySelector("#timecodeField");
const methodHint = document.querySelector("#methodHint");
const button = document.querySelector("#patchButton");
const progressWrap = document.querySelector("#progressWrap");
const status = document.querySelector("#status");
const message = document.querySelector("#message");

function showFile(file) {
  if (!file) return;
  document.querySelector("#fileTitle").textContent = file.name;
  document.querySelector("#fileMeta").textContent = `${(file.size / 1024 / 1024).toFixed(1)} MB · MP4`;
}
fileInput.addEventListener("change", () => showFile(fileInput.files[0]));
["dragenter","dragover"].forEach(name => dropZone.addEventListener(name, e => {e.preventDefault();dropZone.classList.add("drag");}));
["dragleave","drop"].forEach(name => dropZone.addEventListener(name, e => {e.preventDefault();dropZone.classList.remove("drag");}));
dropZone.addEventListener("drop", e => {
  const file = e.dataTransfer.files[0];
  if (file) { fileInput.files = e.dataTransfer.files; showFile(file); }
});
method.addEventListener("change", () => {
  const timecode = method.value === "timecode";
  timecodeField.hidden = !timecode;
  methodHint.textContent = timecode
    ? "Adds a separate tmcd timecode track. Original audio/video packets are verified."
    : "Changes only the movie-header duration field. Experimental; original audio/video packets are verified.";
});
form.addEventListener("submit", async e => {
  e.preventDefault();
  message.hidden = true;
  const file = fileInput.files[0];
  if (!file) return showMessage("Choose an MP4 file first.", true);
  if (!file.name.toLowerCase().endsWith(".mp4")) return showMessage("Only MP4 files are supported.", true);
  const data = new FormData();
  data.append("video", file);
  data.append("method", method.value);
  data.append("timecode", document.querySelector("#timecode").value.trim() || "00:00:00:00");
  button.disabled = true;
  progressWrap.hidden = false;
  status.textContent = "Uploading video and running verification…";
  try {
    const response = await fetch("/api/patch", {method:"POST", body:data});
    if (!response.ok) {
      const detail = await response.text();
      let readable = detail;
      try { const parsed = JSON.parse(detail); readable = parsed.detail || detail; } catch {}
      throw new Error(readable.slice(0,1800));
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${file.name.replace(/\.mp4$/i,"")}_DAO.mp4`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    status.textContent = "Patch verified. Your download should begin automatically.";
    showMessage("Done. Compare this result with an untouched upload; a successful patch does not guarantee TikTok will preserve the original quality.", false);
  } catch (err) {
    showMessage(`Patching failed:\n${err.message}`, true);
    status.textContent = "The patch could not be completed.";
  } finally {
    button.disabled = false;
  }
});
function showMessage(text, error) {
  message.textContent = text;
  message.hidden = false;
  message.classList.toggle("error", !!error);
}
